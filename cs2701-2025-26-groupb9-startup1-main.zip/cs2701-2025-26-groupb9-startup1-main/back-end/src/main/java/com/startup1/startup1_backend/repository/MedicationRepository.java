package com.startup1.startup1_backend.repository;

import com.startup1.startup1_backend.entity.Medication;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicationRepository extends JpaRepository<Medication, Long> {
}
