package com.startup1.startup1_backend.repository;

import com.startup1.startup1_backend.entity.MotherProfile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MotherProfileRepository extends JpaRepository<MotherProfile, Long> {
    MotherProfile findByUser_Id(Long userId);
    void deleteByUser_Id(Long userId);
}