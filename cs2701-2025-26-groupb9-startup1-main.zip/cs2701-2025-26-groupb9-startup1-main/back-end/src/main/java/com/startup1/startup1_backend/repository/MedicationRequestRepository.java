package com.startup1.startup1_backend.repository;

import com.startup1.startup1_backend.entity.MedicationRequest;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicationRequestRepository extends JpaRepository<MedicationRequest, Long> {

    List<MedicationRequest> findByRequestStatus(String requestStatus);

    List<MedicationRequest> findByRequesterRequesterId(Long requesterId);

    List<MedicationRequest> findByRequesterUser_IdAndRequestStatusOrderByRequestDateDesc(Long requesterUserId, String requestStatus);
}
