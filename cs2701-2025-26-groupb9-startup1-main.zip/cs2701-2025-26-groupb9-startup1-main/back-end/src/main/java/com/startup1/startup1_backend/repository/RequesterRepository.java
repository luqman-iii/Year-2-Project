package com.startup1.startup1_backend.repository;

import com.startup1.startup1_backend.entity.Requester;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RequesterRepository extends JpaRepository<Requester, Long> {
}
