const API_BASE = "http://localhost:8080";
const PATIENT_FETCH_INTERVAL_MS = 5000;
const PATIENT_RENDER_INTERVAL_MS = 1000;

document.addEventListener("DOMContentLoaded", () => {
  const totalPatients = document.getElementById("total-patients");
  const onTheWayCount = document.getElementById("on-the-way-count");
  const waitingNotesCount = document.getElementById("waiting-notes-count");
  const statusFilter = document.getElementById("status-filter");
  const tableBody = document.querySelector(".table tbody");
  const modal = document.getElementById("patient-modal");
  const modalTitle = document.getElementById("patient-modal-title");
  const modalMeta = document.getElementById("patient-meta");
  const emergencyCard = document.getElementById("patient-emergency-card");
  const previousNotesCard = document.getElementById("patient-previous-notes-card");
  const emergencyDetails = document.getElementById("patient-emergency-details");
  const previousNotesList = document.getElementById("patient-previous-notes-list");
  const currentVisitSection = document.getElementById("current-visit-section");
  const currentVisitSummary = document.getElementById("current-visit-summary");
  const notesList = document.getElementById("patient-notes-list");
  const noteForm = document.getElementById("patient-note-form");
  const noteInput = document.getElementById("patient-note-input");
  const noteFeedback = document.getElementById("patient-note-feedback");
  const closeModalButton = document.getElementById("close-patient-modal");
  const removePatientButton = document.getElementById("remove-patient-button");
  const treatedButton = document.getElementById("mark-treated-button");
  const saveSummaryButton = document.getElementById("save-patient-note");

  let patients = [];
  let selectedPatient = null;
  let selectedPatientDetails = null;
  let fetchTimer = null;
  let renderTimer = null;
  let detailCardResizeObserver = null;

  function normalizeStatus(status) {
    const value = (status || "").trim().toUpperCase().replace(/\s+/g, "_");
    if (value === "ON_THE_WAY" || value === "PENDING") {
      return "ON_THE_WAY";
    }
    if (value === "WAITING_FOR_NOTES") {
      return "WAITING_FOR_NOTES";
    }
    if (value === "ARRIVED" || value === "ACCEPTED") {
      return "ARRIVED";
    }
    if (value === "CANCELLED") {
      return "CANCELLED";
    }
    return value || "ON_THE_WAY";
  }

  function displayStatus(status) {
    switch (normalizeStatus(status)) {
      case "WAITING_FOR_NOTES":
        return "Waiting for notes";
      case "ARRIVED":
        return "Arrived";
      default:
        return "On the way";
    }
  }

  function statusClass(status) {
    switch (normalizeStatus(status)) {
      case "WAITING_FOR_NOTES":
        return "waiting";
      case "ARRIVED":
        return "arrived";
      default:
        return "onway";
    }
  }

  function parseDate(value) {
    if (!value) {
      return null;
    }

    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function formatCountdown(msRemaining) {
    const totalSeconds = Math.max(0, Math.floor(msRemaining / 1000));
    const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
    const seconds = String(totalSeconds % 60).padStart(2, "0");
    return `${minutes}:${seconds}`;
  }

  function formatEta(etaMinutes, status) {
    const normalizedStatus = normalizeStatus(status);
    if (normalizedStatus === "WAITING_FOR_NOTES" || normalizedStatus === "ARRIVED") {
      return "--";
    }
    if (etaMinutes == null || Number.isNaN(Number(etaMinutes))) {
      return "--";
    }
    return `${etaMinutes} Minutes`;
  }

  function formatDateTime(value) {
    if (!value) {
      return "Date not available";
    }
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return value;
    }
    return date.toLocaleString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  function sortNotesByNewest(notes) {
    return [...notes].sort((left, right) => {
      const leftTime = parseDate(left?.createdAt)?.getTime() || 0;
      const rightTime = parseDate(right?.createdAt)?.getTime() || 0;
      return rightTime - leftTime;
    });
  }

  function getPatientTimeline(patient) {
    const normalizedStatus = normalizeStatus(patient.status);
    const visibleAt = parseDate(patient.hospitalVisibleAt);
    const arrivalAt = parseDate(patient.hospitalArrivalAt);
    const now = Date.now();

    if (normalizedStatus === "CANCELLED") {
      return {
        visible: false,
        status: "CANCELLED",
        etaLabel: "--",
      };
    }

    if (normalizedStatus === "WAITING_FOR_NOTES") {
      return {
        visible: true,
        status: "WAITING_FOR_NOTES",
        etaLabel: "--",
      };
    }

    if (visibleAt && now < visibleAt.getTime()) {
      return {
        visible: false,
        status: "UPCOMING",
        etaLabel: "--",
      };
    }

    if (arrivalAt && now >= arrivalAt.getTime()) {
      return {
        visible: true,
        status: "ARRIVED",
        etaLabel: "Arrived",
      };
    }

    if (visibleAt && arrivalAt) {
      return {
        visible: true,
        status: "ON_THE_WAY",
        etaLabel: formatCountdown(arrivalAt.getTime() - now),
      };
    }

    return {
      visible: true,
      status: normalizedStatus,
      etaLabel: formatEta(patient.etaMinutes, normalizedStatus),
    };
  }

  function getVisiblePatients() {
    return patients
      .map((patient) => ({
        patient,
        timeline: getPatientTimeline(patient),
      }))
      .filter((entry) => entry.timeline.visible);
  }

  function isWaitingForNotes(patient) {
    return normalizeStatus(patient.status) === "WAITING_FOR_NOTES";
  }

  function isArrivedPatient(patient) {
    return getPatientTimeline(patient).status === "ARRIVED";
  }

  function updateOverview(allPatients) {
    const visiblePatients = allPatients
      .map((patient) => getPatientTimeline(patient))
      .filter((timeline) => timeline.visible);

    const total = visiblePatients.length;
    const onTheWay = visiblePatients.filter((timeline) => timeline.status === "ON_THE_WAY").length;
    const waiting = visiblePatients.filter((timeline) => timeline.status === "WAITING_FOR_NOTES").length;

    totalPatients.textContent = String(total);
    onTheWayCount.textContent = String(onTheWay);
    waitingNotesCount.textContent = String(waiting);
  }

  function getFilteredPatients() {
    const selectedStatus = statusFilter.value;
    const visiblePatients = getVisiblePatients();
    if (selectedStatus === "ALL") {
      return visiblePatients;
    }
    return visiblePatients.filter((entry) => entry.timeline.status === selectedStatus);
  }

  function renderTable() {
    const filteredPatients = getFilteredPatients();
    if (filteredPatients.length === 0) {
      tableBody.innerHTML = `<tr><td colspan="4" class="empty-row">No patients match the selected filter.</td></tr>`;
      return;
    }

    tableBody.innerHTML = filteredPatients.map(({ patient, timeline }) => {
      const actionLabel = timeline.status === "WAITING_FOR_NOTES" ? "Add Summary" : "View Details";
      return `
        <tr>
          <td>${patient.patient?.name || "Unknown patient"}</td>
          <td><span class="status ${statusClass(timeline.status)}">${displayStatus(timeline.status)}</span></td>
          <td class="eta-cell">${timeline.etaLabel}</td>
          <td><button class="btn-primary view-btn" data-patient-id="${patient.id}">${actionLabel}</button></td>
        </tr>
      `;
    }).join("");

    tableBody.querySelectorAll("[data-patient-id]").forEach((button) => {
      button.addEventListener("click", () => {
        const patientId = Number(button.dataset.patientId);
        const patient = patients.find((entry) => entry.id === patientId);
        if (patient) {
          openPatientModal(patient);
        }
      });
    });
  }

  async function loadPatients() {
    try {
      const response = await fetch(`${API_BASE}/incoming-patients`);
      if (!response.ok) {
        throw new Error(`Unable to load patients (${response.status})`);
      }

      patients = await response.json();
      if (selectedPatient) {
        selectedPatient = patients.find((patient) => patient.id === selectedPatient.id) || selectedPatient;
      }
      updateOverview(patients);
      renderTable();
      updateModalMeta();
    } catch (error) {
      console.error(error);
      tableBody.innerHTML = `<tr><td colspan="4" class="empty-row">Unable to load incoming patients.</td></tr>`;
    }
  }

  async function loadNotes(incomingPatientId) {
    const response = await fetch(`${API_BASE}/treatment-notes/incoming-patient/${incomingPatientId}`);
    if (!response.ok) {
      throw new Error(`Unable to load notes (${response.status})`);
    }
    return response.json();
  }

  async function loadPatientDetails(incomingPatientId) {
    const response = await fetch(`${API_BASE}/incoming-patients/${incomingPatientId}/details`);
    if (!response.ok) {
      throw new Error(`Unable to load patient details (${response.status})`);
    }
    return response.json();
  }

  function renderNotes(notes) {
    if (!Array.isArray(notes) || notes.length === 0) {
      notesList.innerHTML = `<p class="note-empty">No notes yet.</p>`;
      return;
    }

    notesList.innerHTML = sortNotesByNewest(notes).map((note) => `
      <article class="note-card">
        <p>${note.noteText || "Empty note"}</p>
        <span class="note-time">${formatDateTime(note.createdAt)}</span>
      </article>
    `).join("");
  }

  function renderEmergencyDetails(details) {
    if (!details) {
      emergencyDetails.innerHTML = `<p class="note-empty">Emergency details are not available.</p>`;
      return;
    }

    const rows = [
      ["Phone", details.patientPhone || "Not provided"],
      ["Email", details.patientEmail || "Not provided"],
      ["Address", details.patientAddress || "Not provided"],
      ["Pregnancy Status", details.pregnancyStatus || "Not provided"],
      ["Due Date", details.dueDate || "Not provided"],
      ["Conditions", details.conditions || "None recorded"],
      ["Medication", details.medication || "None recorded"],
    ];

    emergencyDetails.innerHTML = rows.map(([label, value]) => `
      <p class="detail-row"><strong>${label}:</strong> ${value}</p>
    `).join("");
  }

  function renderPreviousNotes(notes) {
    if (!Array.isArray(notes) || notes.length === 0) {
      previousNotesList.innerHTML = `<p class="note-empty">No previous visit summaries found.</p>`;
      previousNotesList.scrollTop = 0;
      return;
    }

    previousNotesList.innerHTML = sortNotesByNewest(notes).map((note) => `
      <article class="note-card">
        <p>${note.noteText || "Empty note"}</p>
        <span class="note-time">${formatDateTime(note.createdAt)}</span>
      </article>
    `).join("");
    previousNotesList.scrollTop = 0;
  }

  function syncTopDetailCardHeights() {
    if (!emergencyCard || !previousNotesCard) {
      return;
    }

    previousNotesCard.style.height = "";
    previousNotesList.style.height = "";

    if (window.matchMedia("(max-width: 900px)").matches || modal.classList.contains("hide")) {
      return;
    }

    const emergencyHeight = emergencyCard.offsetHeight;
    if (emergencyHeight > 0) {
      previousNotesCard.style.height = `${Math.ceil(emergencyHeight)}px`;
      const title = previousNotesCard.querySelector(".notes-title");
      const cardStyles = window.getComputedStyle(previousNotesCard);
      const titleStyles = title ? window.getComputedStyle(title) : null;
      const titleHeight = title ? title.getBoundingClientRect().height : 0;
      const titleMarginBottom = titleStyles ? parseFloat(titleStyles.marginBottom) || 0 : 0;
      const paddingTop = parseFloat(cardStyles.paddingTop) || 0;
      const paddingBottom = parseFloat(cardStyles.paddingBottom) || 0;
      const availableHeight = emergencyHeight - paddingTop - paddingBottom - titleHeight - titleMarginBottom;
      previousNotesList.style.height = `${Math.max(availableHeight, 120)}px`;
    }
  }

  function scheduleTopDetailCardSync() {
    window.requestAnimationFrame(() => {
      window.requestAnimationFrame(syncTopDetailCardHeights);
    });
  }

  function setupTopDetailCardSync() {
    if (!("ResizeObserver" in window) || !emergencyCard || detailCardResizeObserver) {
      return;
    }

    detailCardResizeObserver = new window.ResizeObserver(() => {
      scheduleTopDetailCardSync();
    });
    detailCardResizeObserver.observe(emergencyCard);
  }

  function setNoteFeedback(message = "", type = "") {
    if (!noteFeedback) {
      return;
    }

    noteFeedback.textContent = message;
    noteFeedback.className = "note-feedback";
    if (!message) {
      noteFeedback.classList.add("hide");
      return;
    }

    if (type) {
      noteFeedback.classList.add(type);
    }
    noteFeedback.classList.remove("hide");
  }

  function updateModalWorkflow() {
    if (!selectedPatient) {
      currentVisitSection.classList.add("hide");
      removePatientButton.classList.add("hide");
      treatedButton.classList.add("hide");
      return;
    }

    const showTreatedButton = isArrivedPatient(selectedPatient);
    const showCurrentVisitSection = isWaitingForNotes(selectedPatient);

    currentVisitSection.classList.toggle("hide", !showCurrentVisitSection);
    treatedButton.classList.toggle("hide", !showTreatedButton);
    removePatientButton.classList.toggle("hide", !showCurrentVisitSection);
  }

  function updateModalMeta() {
    if (!selectedPatient) {
      return;
    }

    const timeline = getPatientTimeline(selectedPatient);
    modalMeta.textContent = `Status: ${displayStatus(timeline.status)} • ETA: ${timeline.etaLabel} • Created: ${formatDateTime(selectedPatient.createdAt)}`;
    updateModalWorkflow();
  }

  async function openPatientModal(patient) {
    selectedPatient = patient;
    selectedPatientDetails = null;
    modalTitle.textContent = patient.patient?.name || "Patient Details";
    updateModalMeta();
    noteInput.value = "";
    setNoteFeedback("");
    modal.classList.remove("hide");
    modal.setAttribute("aria-hidden", "false");

    try {
      const [notes, details] = await Promise.all([
        loadNotes(patient.id),
        loadPatientDetails(patient.id),
      ]);
      selectedPatientDetails = details;
      renderNotes(notes);
      renderEmergencyDetails(details);
      renderPreviousNotes(details?.previousNotes || []);
      scheduleTopDetailCardSync();
    } catch (error) {
      console.error(error);
      notesList.innerHTML = `<p class="note-empty">Unable to load notes.</p>`;
      emergencyDetails.innerHTML = `<p class="note-empty">Unable to load emergency details.</p>`;
      previousNotesList.innerHTML = `<p class="note-empty">Unable to load previous visit summaries.</p>`;
      scheduleTopDetailCardSync();
    }
  }

  function closeModal() {
    modal.classList.add("hide");
    modal.setAttribute("aria-hidden", "true");
    selectedPatient = null;
    selectedPatientDetails = null;
    noteInput.value = "";
    setNoteFeedback("");
    if (previousNotesCard) {
      previousNotesCard.style.height = "";
    }
    if (previousNotesList) {
      previousNotesList.style.height = "";
    }
  }

  function updateSelectedPatient(updatedPatient) {
    patients = patients.map((patient) => patient.id === updatedPatient.id ? updatedPatient : patient);
    selectedPatient = updatedPatient;
    updateOverview(patients);
    renderTable();
    updateModalMeta();
  }

  async function fetchSelectedPatientFromServer() {
    if (!selectedPatient?.id) {
      return null;
    }

    const response = await fetch(`${API_BASE}/incoming-patients/${selectedPatient.id}`);
    if (!response.ok) {
      throw new Error(`Unable to refresh patient status (${response.status})`);
    }

    const refreshedPatient = await response.json();
    if (refreshedPatient) {
      updateSelectedPatient(refreshedPatient);
    }
    return refreshedPatient;
  }

  async function updatePatientStatus(patientId, status) {
    const patient = patients.find((entry) => entry.id === patientId) || selectedPatient;
    const response = await fetch(`${API_BASE}/incoming-patients/${patientId}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        status,
        etaMinutes: patient?.etaMinutes,
      }),
    });

    if (!response.ok) {
      throw new Error(`Unable to update patient status (${response.status})`);
    }

    const updatedPatient = await response.json();
    if (updatedPatient) {
      updateSelectedPatient(updatedPatient);
    }
    return updatedPatient;
  }

  async function markPatientTreated() {
    if (!selectedPatient) {
      setNoteFeedback("Open a patient record first.", "error");
      return;
    }

    treatedButton.disabled = true;
    try {
      await updatePatientStatus(selectedPatient.id, "WAITING_FOR_NOTES");
      setNoteFeedback("Patient is ready for the visit summary.", "success");
      noteInput.focus();
    } catch (error) {
      console.error(error);
      setNoteFeedback("Unable to mark the patient as treated right now.", "error");
      alert("Unable to mark the patient as treated right now.");
    } finally {
      treatedButton.disabled = false;
    }
  }

  async function saveCurrentSummary() {
    if (!selectedPatient) {
      setNoteFeedback("Open a patient record first.", "error");
      return;
    }

    const noteText = noteInput.value.trim();
    if (!noteText) {
      setNoteFeedback("Write a short visit summary before saving.", "error");
      alert("Write a short visit summary before saving.");
      return;
    }

    if (saveSummaryButton) {
      saveSummaryButton.disabled = true;
      saveSummaryButton.textContent = "Saving...";
    }

    try {
      let patientForSave = selectedPatient;
      if (!isWaitingForNotes(patientForSave)) {
        patientForSave = await fetchSelectedPatientFromServer() || patientForSave;
      }

      if (!isWaitingForNotes(patientForSave)) {
        if (isArrivedPatient(patientForSave)) {
          patientForSave = await updatePatientStatus(patientForSave.id, "WAITING_FOR_NOTES") || patientForSave;
        } else {
          const statusMessage = "Wait for the patient to arrive, then press Treated before saving a summary.";
          setNoteFeedback(statusMessage, "error");
          alert(statusMessage);
          return;
        }
      }

      const noteResponse = await fetch(`${API_BASE}/treatment-notes/incoming-patient/${selectedPatient.id}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ noteText }),
      });

      if (!noteResponse.ok) {
        const errorText = await noteResponse.text();
        throw new Error(errorText || `Unable to save note (${noteResponse.status})`);
      }

      const notes = await loadNotes(selectedPatient.id);
      renderNotes(notes);
      notesList.scrollTop = 0;
      const refreshedDetails = await loadPatientDetails(selectedPatient.id);
      selectedPatientDetails = refreshedDetails;
      renderPreviousNotes(refreshedDetails?.previousNotes || []);
      updateModalMeta();
      noteInput.value = "";
      setNoteFeedback("Visit summary saved.", "success");
      if (saveSummaryButton) {
        saveSummaryButton.textContent = "Saved";
      }
    } catch (error) {
      console.error(error);
      setNoteFeedback(error.message || "Unable to save the note right now.", "error");
      alert(error.message || "Unable to save the note right now.");
    } finally {
      if (saveSummaryButton) {
        saveSummaryButton.disabled = false;
        window.setTimeout(() => {
          saveSummaryButton.textContent = "Save Summary";
        }, 800);
      }
    }
  }

  async function removePatientFromList() {
    if (!selectedPatient) {
      return;
    }

    if (!isWaitingForNotes(selectedPatient)) {
      setNoteFeedback("The patient can only be removed after reaching Waiting for notes.", "error");
      return;
    }

    const shouldRemove = window.confirm("Remove this patient from the hospital list?");
    if (!shouldRemove) {
      return;
    }

    if (removePatientButton) {
      removePatientButton.disabled = true;
      removePatientButton.textContent = "Removing...";
    }

    try {
      await updatePatientStatus(selectedPatient.id, "CANCELLED");
      closeModal();
    } catch (error) {
      console.error(error);
      setNoteFeedback("Unable to remove the patient from the list right now.", "error");
      alert("Unable to remove the patient from the list right now.");
    } finally {
      if (removePatientButton) {
        removePatientButton.disabled = false;
        removePatientButton.textContent = "Remove From List";
      }
    }
  }

  function handleNoteFormSubmit(event) {
    event.preventDefault();
    saveCurrentSummary().catch((error) => {
      console.error(error);
      setNoteFeedback("Unable to save the note right now.", "error");
      alert("Unable to save the note right now.");
    });
  }

  statusFilter.addEventListener("change", renderTable);
  closeModalButton.addEventListener("click", closeModal);
  removePatientButton?.addEventListener("click", () => {
    removePatientFromList().catch((error) => {
      console.error(error);
      setNoteFeedback("Unable to remove the patient from the list right now.", "error");
      alert("Unable to remove the patient from the list right now.");
    });
  });
  treatedButton.addEventListener("click", markPatientTreated);
  noteForm.addEventListener("submit", handleNoteFormSubmit);
  saveSummaryButton?.addEventListener("click", () => {
    saveCurrentSummary().catch((error) => {
      console.error(error);
      setNoteFeedback("Unable to save the note right now.", "error");
      alert("Unable to save the note right now.");
    });
  });
  modal.addEventListener("click", (event) => {
    if (event.target === modal) {
      closeModal();
    }
  });
  window.addEventListener("resize", () => {
    scheduleTopDetailCardSync();
  });

  loadPatients();
  setupTopDetailCardSync();
  fetchTimer = window.setInterval(() => {
    loadPatients().catch(() => {});
  }, PATIENT_FETCH_INTERVAL_MS);
  renderTimer = window.setInterval(() => {
    updateOverview(patients);
    renderTable();
    updateModalMeta();
  }, PATIENT_RENDER_INTERVAL_MS);

  window.addEventListener("beforeunload", () => {
    if (detailCardResizeObserver) {
      detailCardResizeObserver.disconnect();
    }
    if (fetchTimer) {
      window.clearInterval(fetchTimer);
    }
    if (renderTimer) {
      window.clearInterval(renderTimer);
    }
  });
});
