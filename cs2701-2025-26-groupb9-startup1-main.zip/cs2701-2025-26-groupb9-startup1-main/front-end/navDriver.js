const DRIVER_FLAG = "driverNavEnabled";
const AUTH_PAGES = new Set(["signin.html", "signup.html", "forgotpassword.html", "signup2.html"]);
const PROTECTED_HREFS = new Set([
  "medsearch.html",
  "emergency_request.html",
  "request.html",
  "profilepage.html",
  "driver.html",
  "hospitalpage.html",
  "medrequest.html"
]);

function getStoredRole() {
  return (localStorage.getItem("userRole") || "").trim().toUpperCase();
}

function currentPageName() {
  const parts = window.location.pathname.split("/");
  return (parts[parts.length - 1] || "").toLowerCase();
}

function isLoggedIn() {
  const loggedIn = localStorage.getItem("isLoggedIn") === "true"
    || Boolean(localStorage.getItem("authToken"))
    || Boolean(localStorage.getItem("userId"));

  if (loggedIn && localStorage.getItem("isLoggedIn") !== "true") {
    localStorage.setItem("isLoggedIn", "true");
  }

  return loggedIn;
}

function shouldShowDriverNav() {
  if (!isLoggedIn()) {
    return false;
  }

  if (AUTH_PAGES.has(currentPageName())) {
    return false;
  }

  return getStoredRole() === "DRIVER";
}

function updateProtectedNavLinks() {
  const loggedIn = isLoggedIn();

  document.querySelectorAll("a[href]").forEach((link) => {
    const href = ((link.getAttribute("href") || "").split("?")[0]).toLowerCase();
    if (!PROTECTED_HREFS.has(href)) {
      return;
    }

    if (loggedIn) {
      link.classList.remove("is-disabled");
      link.removeAttribute("aria-disabled");
      link.removeAttribute("data-auth-guard");
      return;
    }

    link.classList.add("is-disabled");
    link.setAttribute("aria-disabled", "true");
    link.setAttribute("data-auth-guard", "true");
  });
}

function attachProtectedNavHandlers() {
  document.querySelectorAll('a[data-auth-guard="true"]').forEach((link) => {
    link.addEventListener("click", (event) => {
      if (isLoggedIn()) {
        return;
      }

      event.preventDefault();
      window.location.href = "SignIn.html";
    });
  });
}

function addDriverLinkToNav(nav) {
  if (!nav) return;
  const existing = nav.querySelector('a[href="driver.html"]');
  if (existing) return;

  const homeLink = nav.querySelector('a[href="homepage.html"]');
  if (!homeLink) return;

  const driverLink = document.createElement("a");
  driverLink.href = "driver.html";
  driverLink.textContent = "Driver";

  // copy classes from home to keep styling consistent
  driverLink.className = homeLink.className || "";
  const homeListItem = homeLink.closest("li");
  const listContainer = homeListItem?.parentElement;

  if (homeListItem && listContainer && (listContainer.tagName === "UL" || listContainer.tagName === "OL")) {
    const driverListItem = document.createElement("li");
    driverListItem.appendChild(driverLink);
    homeListItem.insertAdjacentElement("afterend", driverListItem);
    return;
  }

  homeLink.insertAdjacentElement("afterend", driverLink);
}

function removeDriverLinkFromNav(nav) {
  if (!nav) return;
  nav.querySelectorAll('a[href="driver.html"]').forEach((link) => link.remove());
}

function getDriverRestrictionTarget(link) {
  return link?.closest("li") || link;
}

function hideLinkForDriver(link) {
  if (!link) return;

  const target = getDriverRestrictionTarget(link);
  if (!target) return;

  if (!link.hasAttribute("data-driver-hidden")) {
    link.setAttribute("data-driver-hidden", "true");
    target.setAttribute("data-driver-original-display", target.style.display || "");
  }

  link.classList.remove("is-disabled");
  link.removeAttribute("aria-disabled");
  link.removeAttribute("data-driver-locked");
  link.removeAttribute("title");
  target.style.display = "none";
}

function showLinkAfterDriverHide(link) {
  if (!link || !link.hasAttribute("data-driver-hidden")) return;

  const target = getDriverRestrictionTarget(link);
  if (!target) return;

  target.style.display = target.getAttribute("data-driver-original-display") || "";
  target.removeAttribute("data-driver-original-display");
  link.removeAttribute("data-driver-hidden");
}

function dashboardHrefForRole(role) {
  if (role === "HOSPITAL") {
    return "hospitalpage.html";
  }
  if (role === "PHARMACY") {
    return "MedRequest.html";
  }
  return "homepage.html";
}

function applyRestrictedDashboardHomeNav() {
  if (currentPageName() !== "homepage.html" || !isLoggedIn()) {
    return;
  }

  const role = getStoredRole();
  if (role !== "HOSPITAL" && role !== "PHARMACY") {
    return;
  }

  const homeLink = document.querySelector('a[href="homepage.html"]');
  const medSearchLink = document.querySelector('a[href="MedSearch.html"]');
  const emergencyLink = document.querySelector('a[href^="emergency_request.html"]');
  const profileLink = document.querySelector('a[href="profilepage.html"]');
  const loginLink = document.querySelector('[data-role="login"]');

  if (homeLink) {
    homeLink.textContent = "Dashboard";
    homeLink.href = dashboardHrefForRole(role);
  }

  [medSearchLink, emergencyLink, profileLink].forEach((link) => {
    if (!link) return;
    const listItem = link.closest("li");
    if (listItem) {
      listItem.style.display = "none";
    } else {
      link.style.display = "none";
    }
  });

  if (loginLink) {
    loginLink.textContent = "Log out";
    loginLink.href = "SignIn.html";
  }
}

function isDriverSession() {
  return isLoggedIn() && getStoredRole() === "DRIVER";
}

function clearDriverNavRestrictions() {
  if (currentPageName() === "homepage.html") {
    return;
  }

  const restrictedLinks = [
    document.querySelector('a[href="MedSearch.html"]'),
    document.querySelector('a[href="request.html"]'),
    document.querySelector('a[href^="emergency_request.html"]'),
  ];

  restrictedLinks.forEach((link) => {
    if (!link) return;
    showLinkAfterDriverHide(link);
    link.classList.remove("is-disabled");
    link.removeAttribute("aria-disabled");
    link.removeAttribute("data-driver-locked");
    link.removeAttribute("title");
  });
}

function applyDriverNavRestrictions() {
  if (currentPageName() === "homepage.html") {
    return;
  }

  clearDriverNavRestrictions();

  if (!isDriverSession()) {
    return;
  }

  const restrictedLinks = [
    document.querySelector('a[href="MedSearch.html"]'),
    document.querySelector('a[href="request.html"]'),
    document.querySelector('a[href^="emergency_request.html"]'),
  ];

  restrictedLinks.forEach((link) => {
    hideLinkForDriver(link);
  });
}

function ensureDriverNav() {
  document.querySelectorAll(".nav, nav").forEach((nav) => {
    if (shouldShowDriverNav()) {
      addDriverLinkToNav(nav);
      return;
    }

    removeDriverLinkFromNav(nav);
  });
}

function refreshNavState() {
  updateProtectedNavLinks();
  applyRestrictedDashboardHomeNav();
  ensureDriverNav();
  applyDriverNavRestrictions();
}

function attachLogoutClear() {
  const logoutLinks = document.querySelectorAll(
    'a[href="SignIn.html"], a[href="login.html"], a[href="logout.html"]'
  );
  logoutLinks.forEach((link) => {
    link.addEventListener("click", () => {
      localStorage.removeItem(DRIVER_FLAG);
      localStorage.removeItem("isLoggedIn");
      localStorage.removeItem("authToken");
      localStorage.removeItem("userId");
      localStorage.removeItem("userRole");
      localStorage.removeItem("userName");
      localStorage.removeItem("userEmail");
    });
  });
}

function attachDriverRestrictionHandler() {
  document.addEventListener("click", (event) => {
    const lockedLink = event.target.closest('a[data-driver-locked="true"]');
    if (!lockedLink) {
      return;
    }

    event.preventDefault();
  });
}

document.addEventListener("DOMContentLoaded", () => {
  refreshNavState();
  attachProtectedNavHandlers();
  attachLogoutClear();
  attachDriverRestrictionHandler();
});

window.refreshNavigationState = refreshNavState;
