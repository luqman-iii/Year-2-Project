const PAGE_ROLE_REQUIREMENTS = {
  "driver.html": ["DRIVER"],
  "hospitalpage.html": ["HOSPITAL"],
  "medrequest.html": ["PHARMACY"],
};

function getCurrentPageName() {
  const parts = window.location.pathname.split("/");
  return (parts[parts.length - 1] || "").toLowerCase();
}

function getStoredRole() {
  return (localStorage.getItem("userRole") || "").trim().toUpperCase();
}

function redirectToSignIn() {
  window.location.replace("SignIn.html");
}

document.addEventListener("DOMContentLoaded", () => {
  const isLoggedIn = localStorage.getItem("isLoggedIn") === "true"
    || Boolean(localStorage.getItem("authToken"))
    || Boolean(localStorage.getItem("userId"));

  if (isLoggedIn && localStorage.getItem("isLoggedIn") !== "true") {
    localStorage.setItem("isLoggedIn", "true");
  }

  if (!isLoggedIn) {
    redirectToSignIn();
    return;
  }

  const pageName = getCurrentPageName();
  const allowedRoles = PAGE_ROLE_REQUIREMENTS[pageName];
  if (!allowedRoles) {
    return;
  }

  const role = getStoredRole();
  if (!allowedRoles.includes(role)) {
    window.location.replace("homepage.html");
  }
});
