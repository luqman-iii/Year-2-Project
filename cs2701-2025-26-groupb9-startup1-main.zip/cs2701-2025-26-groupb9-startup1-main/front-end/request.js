const BASE_URL = "http://localhost:8080";
const MOTHER_EMERGENCY_SESSION_KEY = "motherEmergencySession";
 
// Read URL parameters passed from emergency_request.html
const params = new URLSearchParams(window.location.search);
const requestIdParam   = params.get("requestId")   || "";
const locationParam   = params.get("location")    || "";
const phoneParam      = params.get("phoneNumber")  || "";
let pollTimer = null;
let countdownTimer = null;
let hasShownDriverAssignedModal = false;
let latestRequestState = null;
let hasMarkedHospitalHandoff = false;

function getMotherEmergencySession() {
  try {
    const raw = sessionStorage.getItem(MOTHER_EMERGENCY_SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function restoreMotherSessionForNavigation() {
  const motherSession = getMotherEmergencySession();
  if (!motherSession) {
    return false;
  }

  localStorage.setItem("isLoggedIn", motherSession.isLoggedIn || "true");
  localStorage.setItem("authToken", motherSession.authToken || "");
  localStorage.setItem("userId", motherSession.userId || "");
  localStorage.setItem("userRole", motherSession.userRole || "Mother");
  localStorage.setItem("userName", motherSession.userName || "");
  localStorage.setItem("userEmail", motherSession.userEmail || "");
  localStorage.removeItem("driverNavEnabled");
  return true;
}

function formatStatus(status) {
  const normalized = (status || "PENDING").replaceAll("_", " ").toLowerCase();
  return normalized.charAt(0).toUpperCase() + normalized.slice(1);
}

function formatEta(etaMinutes) {
  if (etaMinutes == null) {
    return "Awaiting driver";
  }
  return `${etaMinutes} minutes`;
}

function formatCountdown(msRemaining) {
  const totalSeconds = Math.max(0, Math.floor(msRemaining / 1000));
  const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
  const seconds = String(totalSeconds % 60).padStart(2, "0");
  return `${minutes}:${seconds}`;
}

function closeAssignedModal() {
  const modal = document.getElementById("driverAssignedModal");
  modal.classList.add("hidden");
  modal.setAttribute("aria-hidden", "true");
  const reopenButton = document.getElementById("reopenDriverAssignedModal");
  reopenButton.classList.remove("hidden");
}

function startCountdown(request) {
  if (countdownTimer) {
    window.clearInterval(countdownTimer);
  }

  const countdownEl = document.getElementById("modalCountdown");
  const sourceTime = request.updatedAt || request.createdAt;
  if (!sourceTime || request.etaMinutes == null) {
    countdownEl.textContent = "00:00";
    return;
  }

  const endTime = new Date(sourceTime).getTime() + request.etaMinutes * 60 * 1000;
  const updateCountdown = async () => {
    const remaining = endTime - Date.now();
    countdownEl.textContent = formatCountdown(remaining);
    if (remaining <= 0) {
      window.clearInterval(countdownTimer);
      countdownTimer = null;
      if (!hasMarkedHospitalHandoff && requestIdParam) {
        hasMarkedHospitalHandoff = true;
        document.getElementById("reqStatus").textContent = "Driver arrived";
        document.getElementById("etaText").textContent = "Driver arrived for pickup";
        document.getElementById("modalStatusText").textContent =
          "Driver arrived for pickup. The hospital dashboard countdown is now running.";

        const log = document.getElementById("activityLog");
        const li = document.createElement("li");
        li.textContent = "Driver arrived for pickup. Hospital dashboard is now tracking arrival.";
        log.appendChild(li);
      }
    }
  };

  updateCountdown();
  countdownTimer = window.setInterval(updateCountdown, 1000);
}

function showAssignedModal(request) {
  const modal = document.getElementById("driverAssignedModal");
  const reopenButton = document.getElementById("reopenDriverAssignedModal");
  document.getElementById("modalDriverName").textContent = request.driverName || "Assigned driver";
  document.getElementById("modalPhoneNumber").textContent = request.phoneNumber || "Not provided";
  document.getElementById("modalLocation").textContent = request.location || "Not provided";
  document.getElementById("modalEta").textContent = formatEta(request.etaMinutes);
  document.getElementById("modalStatusText").textContent =
    request.driverName
      ? `${request.driverName} accepted your request and is on the way.`
      : "A driver accepted your request and is on the way.";

  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  reopenButton.classList.add("hidden");
  hasShownDriverAssignedModal = true;
  startCountdown(request);
}

function buildActivityItems(request) {
  const items = [];
  const createdText = request.createdAt
    ? new Date(request.createdAt).toLocaleTimeString()
    : new Date().toLocaleTimeString();

  items.push(`Request submitted at ${createdText}`);

  if (request.status === "PENDING") {
    items.push("Waiting for a driver to accept the request");
  }

  if (request.driverName) {
    items.push(`Driver assigned: ${request.driverName}`);
  }

  if (request.etaMinutes != null) {
    items.push(`Driver en route - ETA ${request.etaMinutes} minutes`);
  }

  if (request.status === "COMPLETED") {
    items.push("Emergency transport completed");
  }

  return items;
}

function renderRequest(request) {
  const previousStatus = latestRequestState?.status || null;
  latestRequestState = request;

  if (locationParam) {
    document.getElementById("location").value = locationParam;
  } else if (request.location) {
    document.getElementById("location").value = request.location;
  }

  if (phoneParam) {
    document.getElementById("phoneNumber").value = phoneParam;
  } else if (request.phoneNumber) {
    document.getElementById("phoneNumber").value = request.phoneNumber;
  }

  document.getElementById("reqStatus").textContent = formatStatus(request.status);
  document.getElementById("driverName").textContent = request.driverName || "Waiting for driver";
  document.getElementById("etaText").textContent = formatEta(request.etaMinutes);

  if (hasMarkedHospitalHandoff && request.status === "DRIVER_ASSIGNED") {
    document.getElementById("reqStatus").textContent = "Driver arrived";
    document.getElementById("etaText").textContent = "Driver arrived for pickup";
  }

  const log = document.getElementById("activityLog");
  log.innerHTML = "";

  buildActivityItems(request).forEach((msg) => {
    const li = document.createElement("li");
    li.textContent = msg;
    log.appendChild(li);
  });

  if (request.status === "DRIVER_ASSIGNED") {
    if (!hasShownDriverAssignedModal || previousStatus !== "DRIVER_ASSIGNED") {
      showAssignedModal(request);
    } else {
      startCountdown(request);
    }
  }
}

async function refreshRequest() {
  if (!requestIdParam) {
    return;
  }

  const response = await fetch(`${BASE_URL}/emergency-requests/${requestIdParam}`);
  if (!response.ok) {
    throw new Error("Could not load your emergency request.");
  }

  const request = await response.json();
  renderRequest(request);
}

document.addEventListener("DOMContentLoaded", async () => {
  const btn = document.getElementById("requestBtn");
  const profileLink = document.querySelector('a[href="profilepage.html"]');
  const reopenButton = document.getElementById("reopenDriverAssignedModal");
  btn.textContent = "Request Submitted";
  btn.disabled = true;

  if (locationParam) {
    document.getElementById("location").value = locationParam;
  }
  if (phoneParam) {
    document.getElementById("phoneNumber").value = phoneParam;
  }

  try {
    if (requestIdParam) {
      await refreshRequest();
      pollTimer = window.setInterval(() => {
        refreshRequest().catch(() => {});
      }, 5000);
    } else {
      document.getElementById("reqStatus").textContent = "Submitted";
      document.getElementById("driverName").textContent = "Waiting for driver";
      document.getElementById("etaText").textContent = "Awaiting driver";
    }
  } catch (error) {
    const log = document.getElementById("activityLog");
    log.innerHTML = "";
    const li = document.createElement("li");
    li.textContent = error.message;
    log.appendChild(li);
  }

  document.getElementById("closeDriverAssignedModal").addEventListener("click", closeAssignedModal);
  reopenButton.addEventListener("click", () => {
    if (latestRequestState) {
      showAssignedModal(latestRequestState);
    }
  });

  profileLink?.addEventListener("click", () => {
    restoreMotherSessionForNavigation();
  });
});

window.addEventListener("beforeunload", () => {
  if (pollTimer) {
    window.clearInterval(pollTimer);
  }
  if (countdownTimer) {
    window.clearInterval(countdownTimer);
  }
});
