const API_BASE = "http://localhost:8080";
const PENDING_PROFILE_ROLE_USER_ID_KEY = "pendingProfileRoleUserId";

document.addEventListener("DOMContentLoaded", () => {
  const motherTab = document.getElementById("mother-tab");
  const driverTab = document.getElementById("driver-tab");
  const motherPanel = document.getElementById("mother-panel");
  const driverPanel = document.getElementById("driver-panel");
  const subtitle = document.querySelector(".page-subtitle");
  const saveButton = document.getElementById("save-button");
  const modalBG = document.getElementById("save-modal");
  const closeButton = document.getElementById("close-modal-button");
  const nav = document.querySelector(".nav");
  const personalForm = document.getElementById("personal-form");
  const motherForm = document.getElementById("mother-form");
  const driverForm = document.getElementById("driver-form");

  const userId = localStorage.getItem("userId");
  let activeRole = "MOTHER";
  let lockedRole = (localStorage.getItem("userRole") || "").trim().toUpperCase() || "MOTHER";
  let hasPendingRoleChoice = Boolean(userId)
    && localStorage.getItem(PENDING_PROFILE_ROLE_USER_ID_KEY) === userId;

  const motherText =
    "Update your personal and health details so doctors can prepare faster during emergencies.";
  const driverText =
    "Update your personal and vehicle details to support safe and efficient emergency transport.";

  function setSubtitle(showMother) {
    if (!subtitle) return;
    subtitle.textContent = showMother ? motherText : driverText;
  }

  function formatRole(role) {
    const normalized = (role || "").toLowerCase();
    if (!normalized) return "";
    return normalized.charAt(0).toUpperCase() + normalized.slice(1);
  }

  function normalizeRole(role) {
    return (role || "").trim().toUpperCase();
  }

  function switchTabs(showMother) {
    activeRole = showMother ? "MOTHER" : "DRIVER";
    motherTab.classList.toggle("active", showMother);
    driverTab.classList.toggle("active", !showMother);

    motherPanel.classList.toggle("hidden", !showMother);
    driverPanel.classList.toggle("hidden", showMother);

    motherTab.setAttribute("aria-selected", String(showMother));
    driverTab.setAttribute("aria-selected", String(!showMother));
    motherPanel.setAttribute("aria-hidden", String(!showMother));
    driverPanel.setAttribute("aria-hidden", String(showMother));

    setSubtitle(showMother);
  }

  function applyRoleTabs(role) {
    const normalizedRole = normalizeRole(role) || "MOTHER";
    const isDriver = normalizedRole === "DRIVER";
    const isPersonalRole = normalizedRole === "MOTHER" || normalizedRole === "DRIVER";
    const showRoleChoice = isPersonalRole && hasPendingRoleChoice;

    lockedRole = normalizedRole;

    if (motherTab) {
      motherTab.hidden = !showRoleChoice && isDriver;
      motherTab.disabled = !isPersonalRole;
    }

    if (driverTab) {
      driverTab.hidden = !showRoleChoice && !isDriver;
      driverTab.disabled = !isPersonalRole;
    }

    switchTabs(showRoleChoice ? activeRole !== "DRIVER" : !isDriver);
  }

  function openModal(message, isError = false) {
    const title = modalBG?.querySelector(".modal-title");
    const text = modalBG?.querySelector(".modal-text");
    if (title) {
      title.textContent = isError ? "Unable to Save" : "Changes Saved";
    }
    if (text) {
      text.textContent = message;
    }
    if (modalBG) {
      modalBG.classList.remove("hide");
      modalBG.setAttribute("aria-hidden", "false");
    }
  }

  function closeModal() {
    if (!modalBG) return;
    modalBG.classList.add("hide");
    modalBG.setAttribute("aria-hidden", "true");
  }

  function getFormValues(form) {
    return Object.fromEntries(new FormData(form).entries());
  }

  function fillForm(form, values) {
    Object.entries(values).forEach(([name, value]) => {
      const field = form.elements.namedItem(name);
      if (field) {
        field.value = value ?? "";
      }
    });
  }

  function ensureDriverNavLink() {
    if (!nav) return;
    const existingDriverLink = nav.querySelector('a[href="driver.html"]');
    if (existingDriverLink) return;

    const homeLink = nav.querySelector('a[href="homepage.html"]');
    const driverLink = document.createElement("a");
    driverLink.href = "driver.html";
    driverLink.textContent = "Driver";
    driverLink.className = "nav-item";

    if (homeLink && homeLink.nextSibling) {
      nav.insertBefore(driverLink, homeLink.nextSibling);
    } else {
      nav.appendChild(driverLink);
    }
  }

  function removeDriverNavLink() {
    if (!nav) return;
    nav.querySelectorAll('a[href="driver.html"]').forEach((link) => link.remove());
  }

  async function requestJson(url, options = {}) {
    const response = await fetch(url, {
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {}),
      },
      ...options,
    });

    if (!response.ok) {
      const text = await response.text();
      throw new Error(text || `Request failed with status ${response.status}`);
    }

    if (response.status === 204) {
      return null;
    }

    return response.json();
  }

  async function loadProfile() {
    if (!userId) {
      openModal("No signed-in user was found. Please sign in again.", true);
      return;
    }

    try {
      const user = await requestJson(`${API_BASE}/users/${userId}`, { headers: {} });
      if (user) {
        fillForm(personalForm, {
          name: user.name,
          phone: user.phone,
          email: user.email,
          address: user.address,
        });
        applyRoleTabs(user.role);
      }

      try {
        const motherProfile = await requestJson(`${API_BASE}/mother-profiles/user/${userId}`, { headers: {} });
        if (motherProfile) {
          fillForm(motherForm, {
            pregnancyStatus: motherProfile.pregnancyStatus,
            dueDate: motherProfile.dueDate,
            conditions: motherProfile.conditions,
            medication: motherProfile.medication,
          });
        }
      } catch (error) {
        console.debug("Mother profile not loaded", error);
      }

      try {
        const driverProfile = await requestJson(`${API_BASE}/driver-profiles/user/${userId}`, { headers: {} });
        if (driverProfile) {
          fillForm(driverForm, {
            licenceNumber: driverProfile.licenceNumber,
            vehicleType: driverProfile.vehicleType,
            vehiclePlate: driverProfile.vehiclePlate,
            area: driverProfile.area,
            experience: driverProfile.experience,
          });
          if (lockedRole === "DRIVER") {
            localStorage.setItem("driverNavEnabled", "true");
            localStorage.setItem("userRole", "Driver");
            ensureDriverNavLink();
          }
        }
      } catch (error) {
        console.debug("Driver profile not loaded", error);
      }
    } catch (error) {
      console.error(error);
      openModal("Unable to load profile data. Please make sure the backend is running.", true);
    }
  }

  async function saveProfile() {
    if (!userId) {
      openModal("No signed-in user was found. Please sign in again.", true);
      return;
    }

    const personal = getFormValues(personalForm);
    const mother = getFormValues(motherForm);
    const driver = getFormValues(driverForm);
    const roleToSave = hasPendingRoleChoice ? activeRole : lockedRole;

    try {
      await requestJson(`${API_BASE}/users/${userId}`, {
        method: "PUT",
        body: JSON.stringify({
          role: roleToSave,
          name: personal.name || "",
          phone: personal.phone || "",
          email: personal.email || "",
          address: personal.address || "",
        }),
      });

      if (roleToSave === "MOTHER") {
        const motherPayload = {
          pregnancyStatus: mother.pregnancyStatus || "",
          dueDate: mother.dueDate || null,
          conditions: mother.conditions || "",
          medication: mother.medication || "",
        };

        try {
          await requestJson(`${API_BASE}/mother-profiles/user/${userId}`, {
            method: "PUT",
            body: JSON.stringify(motherPayload),
          });
        } catch (error) {
          await requestJson(`${API_BASE}/mother-profiles/user/${userId}`, {
            method: "POST",
            body: JSON.stringify(motherPayload),
          });
        }

        localStorage.removeItem("driverNavEnabled");
        localStorage.setItem("userRole", formatRole(roleToSave));
        removeDriverNavLink();
      } else {
        const driverPayload = {
          licenceNumber: driver.licenceNumber || "",
          vehicleType: driver.vehicleType || "",
          vehiclePlate: driver.vehiclePlate || "",
          area: driver.area || "",
          experience: driver.experience || "",
        };

        try {
          await requestJson(`${API_BASE}/driver-profiles/user/${userId}`, {
            method: "PUT",
            body: JSON.stringify(driverPayload),
          });
        } catch (error) {
          await requestJson(`${API_BASE}/driver-profiles/user/${userId}`, {
            method: "POST",
            body: JSON.stringify(driverPayload),
          });
        }

        localStorage.setItem("driverNavEnabled", "true");
        localStorage.setItem("userRole", formatRole(roleToSave));
        ensureDriverNavLink();
      }

      hasPendingRoleChoice = false;
      localStorage.removeItem(PENDING_PROFILE_ROLE_USER_ID_KEY);
      applyRoleTabs(roleToSave);
      window.refreshNavigationState?.();
      openModal("Your profile information has been updated successfully.");
    } catch (error) {
      console.error(error);
      openModal("Unable to save profile changes. Please make sure the backend is running.", true);
    }
  }

  motherTab?.addEventListener("click", () => {
    if (hasPendingRoleChoice) {
      switchTabs(true);
    }
  });
  driverTab?.addEventListener("click", () => {
    if (hasPendingRoleChoice) {
      switchTabs(false);
    }
  });
  saveButton?.addEventListener("click", saveProfile);
  closeButton?.addEventListener("click", closeModal);

  applyRoleTabs(lockedRole);
  loadProfile();
});
