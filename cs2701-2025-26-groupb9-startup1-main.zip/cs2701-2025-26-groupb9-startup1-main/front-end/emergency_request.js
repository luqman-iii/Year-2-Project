const BASE_URL = "http://localhost:8080";
const MOTHER_EMERGENCY_SESSION_KEY = "motherEmergencySession";
 
async function submitRequest() {
  const location = document.getElementById("location").value.trim();
  const btn = document.getElementById("confirmBtn");
  const userId = localStorage.getItem("userId");
  const userEmail = (localStorage.getItem("userEmail") || "").trim().toLowerCase();
  const userName = (localStorage.getItem("userName") || "").trim();
 
  if (!location) {
    alert("Please enter your location.");
    return;
  }
  if (!userId) {
    alert("You need to be signed in to request emergency transport.");
    return;
  }
 
  btn.disabled = true;
  btn.textContent = "Processing...";
 
  try {
    const patientRes = await fetch(`${BASE_URL}/users`);
    if (!patientRes.ok) throw new Error("Could not reach the server. Is Spring Boot running?");
    const users = await patientRes.json();
    const patient = users.find((user) =>
      String(user.id) === String(userId)
      || (userEmail && (user.email || "").trim().toLowerCase() === userEmail)
      || (userName && (user.name || "").trim() === userName)
    );

    if (!patient || !patient.id) {
      throw new Error("Could not find your account details.");
    }
 
    const driverRes = await fetch(`${BASE_URL}/driver`);
    if (!driverRes.ok) throw new Error("Could not fetch drivers.");
    const drivers = await driverRes.json();
 
    if (!drivers || drivers.length === 0) {
      throw new Error("No drivers available right now. Please try again shortly.");
    }
 
    const assignedDriver = drivers[0];
 
    const requestRes = await fetch(`${BASE_URL}/emergency-requests`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        patientId: patient.id,
        patientLookup: userEmail || patient.phone || "",
        status: "PENDING",
        location: location,
        phoneNumber: patient.phone || ""
      })
    });
 
    if (!requestRes.ok) throw new Error("Failed to create request: " + await requestRes.text());
    const createdRequest = await requestRes.json();

    sessionStorage.setItem(MOTHER_EMERGENCY_SESSION_KEY, JSON.stringify({
      isLoggedIn: localStorage.getItem("isLoggedIn") || "true",
      authToken: localStorage.getItem("authToken") || "",
      userId: String(patient.id),
      userRole: localStorage.getItem("userRole") || "Mother",
      userName: patient.name || localStorage.getItem("userName") || "",
      userEmail: patient.email || localStorage.getItem("userEmail") || ""
    }));
 
    const params = new URLSearchParams({
      requestId: createdRequest.requestId,
      location: location,
      phoneNumber: patient.phone || "",
      patientName: patient.name || localStorage.getItem("userName") || ""
    });
 
    window.location.href = `request.html?${params.toString()}`;
 
  } catch (error) {
    alert(error.message);
    btn.disabled = false;
    btn.textContent = "Confirm request";
  }
}
 
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("confirmBtn").addEventListener("click", submitRequest);
});
