const API_BASE = "http://localhost:8080";

const signInForm = document.getElementById("sign-in-form");
const loginField = document.getElementById("login-email-or-phone");
const passwordField = document.getElementById("login-password");
const signInMessage = document.getElementById("sign-in-message");
const homeLink = document.querySelector('.nav-link[href="homepage.html"]');

function clearSession() {
  localStorage.setItem("isLoggedIn", "false");
  localStorage.removeItem("authToken");
  localStorage.removeItem("userId");
  localStorage.removeItem("userRole");
  localStorage.removeItem("userName");
  localStorage.removeItem("userEmail");
  localStorage.removeItem("driverNavEnabled");
}

function setMessage(message, isError = false) {
  if (!signInMessage) return;
  signInMessage.textContent = message;
  signInMessage.style.color = isError ? "#b42318" : "#475467";
}

function formatRole(role) {
  const normalized = (role || "").toLowerCase();
  if (!normalized) return "";
  return normalized.charAt(0).toUpperCase() + normalized.slice(1);
}

function saveSession(data) {
  localStorage.setItem("isLoggedIn", "true");
  localStorage.setItem("authToken", data.token || "");
  localStorage.setItem("userId", String(data.userId || ""));
  localStorage.setItem("userRole", formatRole(data.role));
  localStorage.setItem("userName", data.name || "");
  localStorage.setItem("userEmail", data.email || "");
}

function getRoleDestination(role) {
  switch ((role || "").toUpperCase()) {
    case "HOSPITAL":
      return "hospitalpage.html";
    case "PHARMACY":
      return "MedRequest.html";
    case "DRIVER":
    case "MOTHER":
      return "profilepage.html";
    default:
      return "homepage.html";
  }
}

clearSession();

homeLink?.addEventListener("click", () => {
  clearSession();
});

signInForm?.addEventListener("submit", async (event) => {
  event.preventDefault();

  const emailOrPhone = loginField.value.trim();
  const password = passwordField.value;

  if (!emailOrPhone || !password) {
    setMessage("Enter your email/phone and password.", true);
    return;
  }

  setMessage("Signing in...");

  try {
    const response = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ emailOrPhone, password }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || "Sign in failed.");
    }

    const data = await response.json();
    saveSession(data);
    window.location.href = getRoleDestination(data.role);
  } catch (error) {
    console.error(error);
    const isNetworkError = error instanceof TypeError;
    setMessage(
      isNetworkError
        ? "Unable to reach the server. Make sure the backend is running on http://localhost:8080."
        : (error.message || "Unable to sign in."),
      true
    );
  }
});
