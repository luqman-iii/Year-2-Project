function getStoredRole() {
  return (localStorage.getItem('userRole') || '').trim().toUpperCase();
}

function hasActiveSession() {
  return localStorage.getItem('isLoggedIn') === 'true'
    || Boolean(localStorage.getItem('authToken'))
    || Boolean(localStorage.getItem('userId'));
}

let isLoggedIn = hasActiveSession();
let normalizedRole = getStoredRole();

if (isLoggedIn && localStorage.getItem('isLoggedIn') !== 'true') {
  localStorage.setItem('isLoggedIn', 'true');
}

const loginLink = document.querySelector('[data-role="login"]');
const protectedLinks = document.querySelectorAll('[data-requires-auth]');
const homeLink = document.querySelector('a[href="homepage.html"]');
const medSearchLink = document.querySelector('a[href="MedSearch.html"]');
const emergencyLink = document.querySelector('a[href^="emergency_request.html"]');
const profileLink = document.querySelector('a[href="profilepage.html"]');
const requestTransportButton = document.getElementById('request-transport-button');
const homepageProtectedNavLinks = [medSearchLink, emergencyLink, profileLink];
const driverHiddenHomepageNavLinks = [medSearchLink, emergencyLink];

function isRestrictedDashboardRole() {
  return normalizedRole === 'HOSPITAL' || normalizedRole === 'PHARMACY';
}

function isDriverRole() {
  return normalizedRole === 'DRIVER';
}

function dashboardHrefForRole() {
  if (normalizedRole === 'HOSPITAL') {
    return 'hospitalpage.html';
  }
  if (normalizedRole === 'PHARMACY') {
    return 'MedRequest.html';
  }
  return 'homepage.html';
}

function toggleNavItem(link, visible) {
  if (!link) return;
  const listItem = link.closest('li');
  if (listItem) {
    listItem.style.display = visible ? '' : 'none';
  } else {
    link.style.display = visible ? '' : 'none';
  }
}

function updateRoleAwareNav() {
  normalizedRole = getStoredRole();
  isLoggedIn = hasActiveSession();

  if (!isLoggedIn) {
    if (homeLink) {
      homeLink.textContent = 'Home';
      homeLink.href = 'homepage.html';
    }
    homepageProtectedNavLinks.forEach((link) => toggleNavItem(link, false));
    return;
  }

  if (isDriverRole()) {
    if (homeLink) {
      homeLink.textContent = 'Home';
      homeLink.href = 'homepage.html';
    }
    driverHiddenHomepageNavLinks.forEach((link) => toggleNavItem(link, false));
    toggleNavItem(profileLink, true);
    return;
  }

  if (!isRestrictedDashboardRole()) {
    if (homeLink) {
      homeLink.textContent = 'Home';
      homeLink.href = 'homepage.html';
    }
    homepageProtectedNavLinks.forEach((link) => toggleNavItem(link, true));
    return;
  }

  if (homeLink) {
    homeLink.textContent = 'Dashboard';
    homeLink.href = dashboardHrefForRole();
  }
  homepageProtectedNavLinks.forEach((link) => toggleNavItem(link, false));
}

function updateLoginButton() {
  if (!loginLink) return;

  if (isLoggedIn) {
    loginLink.textContent = 'Log out';
    loginLink.href = 'SignIn.html';
  } else {
    loginLink.textContent = 'Login';
    loginLink.href = 'SignIn.html';
  }
}

function updateProtectedLinks() {
  protectedLinks.forEach((link) => {
    if (isLoggedIn) {
      link.classList.remove('is-disabled');
      link.removeAttribute('aria-disabled');
      link.tabIndex = 0;
    } else {
      link.classList.add('is-disabled');
      link.setAttribute('aria-disabled', 'true');
      link.tabIndex = -1;
    }
  });
}

function updateEmergencyActionsForDriver() {
  if (!requestTransportButton) return;

  const hideRequestButton = isLoggedIn && (isDriverRole() || isRestrictedDashboardRole());
  requestTransportButton.hidden = hideRequestButton;
  requestTransportButton.style.display = hideRequestButton ? 'none' : '';

  if (hideRequestButton) {
    requestTransportButton.classList.add('is-disabled');
    requestTransportButton.disabled = true;
    requestTransportButton.setAttribute('aria-disabled', 'true');
    requestTransportButton.removeAttribute('title');
    return;
  }

  const disableRequestButton = !isLoggedIn;

  requestTransportButton.classList.toggle('is-disabled', disableRequestButton);
  requestTransportButton.disabled = disableRequestButton;
  requestTransportButton.setAttribute('aria-disabled', String(disableRequestButton));

  if (!isLoggedIn) {
    requestTransportButton.setAttribute('title', 'Please log in to request emergency transport.');
  } else if (isDriverRole()) {
    requestTransportButton.setAttribute('title', 'Emergency transport requests are only available for mothers.');
  } else if (isRestrictedDashboardRole()) {
    requestTransportButton.setAttribute('title', 'Emergency transport requests are not available for hospital or pharmacy accounts.');
  } else {
    requestTransportButton.removeAttribute('title');
  }
}

function requireLogin(event) {
  if (isLoggedIn) return;

  event.preventDefault();
  alert('Please log in.');
  window.location.href = 'SignIn.html';
}

function blockDriverEmergencyRequest(event) {
  if (!isLoggedIn || !isDriverRole()) return;

  event.preventDefault();
  alert('Drivers cannot request emergency transport.');
}

protectedLinks.forEach((link) => {
  link.addEventListener('click', requireLogin);
});

requestTransportButton?.addEventListener('click', (event) => {
  if (!isLoggedIn) {
    requireLogin(event);
    return;
  }

  if (isDriverRole()) {
    blockDriverEmergencyRequest(event);
    return;
  }

  if (isRestrictedDashboardRole()) {
    event.preventDefault();
    return;
  }

  window.location.href = 'emergency_request.html?v=2';
});

if (loginLink) {
  loginLink.addEventListener('click', (event) => {
    if (!isLoggedIn) return;

    event.preventDefault();
    isLoggedIn = false;
    localStorage.setItem('isLoggedIn', 'false');
    localStorage.removeItem('authToken');
    localStorage.removeItem('userId');
    localStorage.removeItem('userRole');
    localStorage.removeItem('userName');
    localStorage.removeItem('userEmail');
    localStorage.removeItem('driverNavEnabled');
    refreshHomepageState();
    window.location.href = 'SignIn.html';
  });
}

function refreshHomepageState() {
  normalizedRole = getStoredRole();
  isLoggedIn = hasActiveSession();

  updateLoginButton();
  updateProtectedLinks();
  updateRoleAwareNav();
  if (typeof window.refreshNavigationState === 'function') {
    window.refreshNavigationState();
  }
  updateEmergencyActionsForDriver();
}

window.addEventListener('pageshow', refreshHomepageState);
window.addEventListener('focus', refreshHomepageState);
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    refreshHomepageState();
  }
});

refreshHomepageState();
