const roleButtons = document.querySelectorAll('.role');
const signUpForm = document.getElementById('sign-up-form');
const businessGroup = document.getElementById('business-group');
const navHomeLink = document.querySelector('.nav-link');
const nameGroup = document.getElementById('name-group');
const businessNameInput = document.getElementById('businessName');
const fullNameInput = document.getElementById('fullName');
const emailInput = document.getElementById('email');
const phoneInput = document.getElementById('phone');
const addressInput = document.getElementById('address');
const passwordInput = document.getElementById('password');
const confirmPasswordInput = document.getElementById('confirmPassword');
const signUpMessage = document.getElementById('sign-up-message');
const API_BASE = "http://localhost:8080";
const PENDING_PROFILE_ROLE_USER_ID_KEY = "pendingProfileRoleUserId";
let selectedRole = null;
let selectedTarget = 'profilepage.html';

function isBusinessRole(role) {
  return role === 'PHARMACY' || role === 'HOSPITAL';
}

function toggleBusiness(show) {
  if (!businessGroup) return;
  businessGroup.classList.toggle('hidden', !show);
  if (nameGroup) {
    nameGroup.classList.toggle('hidden', show);
  }
}

function setMessage(message, isError = false) {
  if (!signUpMessage) return;
  signUpMessage.textContent = message;
  signUpMessage.style.color = isError ? "#b42318" : "#475467";
}

function formatRole(role) {
  const normalized = (role || "").toLowerCase();
  if (!normalized) return "";
  return normalized.charAt(0).toUpperCase() + normalized.slice(1);
}

function saveSession(data) {
  localStorage.setItem("isLoggedIn", "true");
  localStorage.setItem("authToken", data.token || "");
  localStorage.setItem("userId", String(data.userId || ""));
  localStorage.setItem("userRole", formatRole(data.role));
  localStorage.setItem("userName", data.name || "");
  localStorage.setItem("userEmail", data.email || "");
}

roleButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    const isActive = btn.classList.contains('active');
    roleButtons.forEach((roleButton) => {
      roleButton.classList.remove('active');
      roleButton.setAttribute('aria-pressed', 'false');
    });

    if (isActive) {
      selectedRole = null;
      selectedTarget = 'profilepage.html';
      toggleBusiness(false);
      return;
    }

    btn.classList.add('active');
    btn.setAttribute('aria-pressed', 'true');
    selectedRole = btn.dataset.role;
    selectedTarget = btn.dataset.target;
    toggleBusiness(isBusinessRole(selectedRole));
  });
});

signUpForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const effectiveRole = selectedRole || 'MOTHER';

  if (passwordInput.value !== confirmPasswordInput.value) {
    setMessage('Passwords do not match.', true);
    return;
  }

  const payload = {
    role: effectiveRole,
    name: fullNameInput.value.trim(),
    businessName: businessNameInput.value.trim(),
    phone: phoneInput.value.trim(),
    email: emailInput.value.trim(),
    address: addressInput.value.trim(),
    password: passwordInput.value
  };

  if (!payload.email || !payload.password) {
    setMessage('Email and password are required.', true);
    return;
  }

  if (isBusinessRole(effectiveRole) && !payload.businessName) {
    setMessage('Business name is required for hospital and pharmacy accounts.', true);
    return;
  }

  if (!payload.name && !payload.businessName) {
    setMessage('Name is required.', true);
    return;
  }

  setMessage('Creating account...');

  try {
    const response = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || 'Registration failed.');
    }

    const data = await response.json();
    saveSession(data);
    if (selectedRole) {
      localStorage.removeItem(PENDING_PROFILE_ROLE_USER_ID_KEY);
    } else {
      localStorage.setItem(PENDING_PROFILE_ROLE_USER_ID_KEY, String(data.userId || ""));
    }
    window.location.href = selectedTarget || 'homepage.html';
  } catch (error) {
    console.error(error);
    const isNetworkError = error instanceof TypeError;
    setMessage(
      isNetworkError
        ? 'Unable to reach the server. Make sure the backend is running on http://localhost:8080.'
        : (error.message || 'Unable to create account.'),
      true
    );
  }
});

if (navHomeLink) {
  navHomeLink.addEventListener('click', () => {
    window.location.href = 'homepage.html';
  });
}
