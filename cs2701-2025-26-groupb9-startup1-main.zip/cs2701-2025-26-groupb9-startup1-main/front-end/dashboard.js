const API_BASE = "http://localhost:8080";
const DECLINED_REQUESTS_KEY_PREFIX = "driverDeclinedRequests:";

const requestsContainer = document.getElementById("driverRequests");
const driverMessage = document.getElementById("driverMessage");
let refreshTimer = null;

function currentDriverId() {
  return localStorage.getItem("userId");
}

function declinedRequestsStorageKey() {
  return `${DECLINED_REQUESTS_KEY_PREFIX}${currentDriverId() || "unknown"}`;
}

function getDeclinedRequestIds() {
  try {
    const raw = localStorage.getItem(declinedRequestsStorageKey());
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.map(Number).filter(Number.isFinite) : [];
  } catch {
    return [];
  }
}

function saveDeclinedRequestIds(requestIds) {
  localStorage.setItem(declinedRequestsStorageKey(), JSON.stringify(requestIds));
}

function addDeclinedRequestId(requestId) {
  const requestIds = new Set(getDeclinedRequestIds());
  requestIds.add(Number(requestId));
  saveDeclinedRequestIds([...requestIds]);
}

function removeDeclinedRequestId(requestId) {
  const requestIds = getDeclinedRequestIds().filter((id) => id !== Number(requestId));
  saveDeclinedRequestIds(requestIds);
}

function formatCreatedAt(createdAt) {
  if (!createdAt) {
    return "Just now";
  }
  return new Date(createdAt).toLocaleString();
}

function createRequestCard(request) {
  const card = document.createElement("div");
  card.className = "request-card";

  const title = document.createElement("p");
  title.innerHTML = `<strong>${request.patientName || "Mother request"}</strong> - ${request.location || "Location pending"}`;

  const meta = document.createElement("p");
  meta.textContent = `${formatCreatedAt(request.createdAt)} - ${request.phoneNumber || "No phone number"}`;

  const etaLabel = document.createElement("label");
  etaLabel.textContent = "ETA (minutes): ";

  const etaInput = document.createElement("input");
  etaInput.type = "number";
  etaInput.min = "1";
  etaInput.value = request.etaMinutes || 1;
  etaInput.style.marginRight = "12px";
  etaInput.style.width = "90px";

  const acceptButton = document.createElement("button");
  acceptButton.className = "request-btn accept-btn";
  acceptButton.textContent = "Accept";
  acceptButton.addEventListener("click", async () => {
    acceptButton.disabled = true;
    declineButton.disabled = true;
    try {
      const response = await fetch(`${API_BASE}/driver/requests/${request.requestId}/accept`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          driverId: Number(currentDriverId()),
          name: localStorage.getItem("userName") || "",
          etaMinutes: Number(etaInput.value) || 1
        })
      });

      if (!response.ok) {
        throw new Error("Failed to accept request.");
      }

      removeDeclinedRequestId(request.requestId);
      driverMessage.textContent = "Request accepted.";
      await loadDriverRequests();
    } catch (error) {
      driverMessage.textContent = error.message;
      acceptButton.disabled = false;
      declineButton.disabled = false;
    }
  });

  const declineButton = document.createElement("button");
  declineButton.className = "request-btn decline-btn";
  declineButton.textContent = "Decline";
  declineButton.addEventListener("click", async () => {
    declineButton.disabled = true;
    acceptButton.disabled = true;
    try {
      const response = await fetch(`${API_BASE}/driver/requests/${request.requestId}/decline`, {
        method: "PUT"
      });

      if (!response.ok) {
        throw new Error("Failed to decline request.");
      }

      addDeclinedRequestId(request.requestId);
      driverMessage.textContent = "Request removed from your list.";
      await loadDriverRequests();
    } catch (error) {
      driverMessage.textContent = error.message;
      declineButton.disabled = false;
      acceptButton.disabled = false;
    }
  });

  card.appendChild(title);
  card.appendChild(meta);
  card.appendChild(etaLabel);
  card.appendChild(etaInput);
  card.appendChild(acceptButton);
  card.appendChild(declineButton);
  return card;
}

async function loadDriverRequests() {
  const driverId = currentDriverId();
  if (!driverId) {
    driverMessage.textContent = "Driver session not found. Sign in again.";
    requestsContainer.innerHTML = "";
    return;
  }

  const response = await fetch(`${API_BASE}/driver/requests`);
  if (!response.ok) {
    throw new Error("Could not load emergency requests.");
  }

  const requests = await response.json();
  const declinedRequestIds = new Set(getDeclinedRequestIds());
  const visibleRequests = requests.filter((request) => !declinedRequestIds.has(Number(request.requestId)));
  requestsContainer.innerHTML = "";

  if (!visibleRequests.length) {
    driverMessage.textContent = "No pending emergency transport requests.";
    return;
  }

  driverMessage.textContent = `${visibleRequests.length} pending request${visibleRequests.length === 1 ? "" : "s"} available.`;
  visibleRequests.forEach((request) => {
    requestsContainer.appendChild(createRequestCard(request));
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  try {
    await loadDriverRequests();
    refreshTimer = window.setInterval(() => {
      loadDriverRequests().catch(() => {});
    }, 5000);
  } catch (error) {
    driverMessage.textContent = error.message;
  }
});

window.addEventListener("beforeunload", () => {
  if (refreshTimer) {
    window.clearInterval(refreshTimer);
  }
});
